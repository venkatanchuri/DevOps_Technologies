kubectl create -f python/namespace/ukns-namespace-create.yaml
kubectl create -f python/namespace/ukns-rc.yaml
kubectl create -f python/namespace/ukns-svc.yaml
