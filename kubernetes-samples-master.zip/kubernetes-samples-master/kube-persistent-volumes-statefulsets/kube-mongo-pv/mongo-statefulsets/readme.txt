
kubectl create -f kube-pv/kube-mongo-pv/mongo-statefulsets/kube-mongo-volumes.yaml
kubectl create -f kube-pv/kube-mongo-pv/mongo-statefulsets/kube-mongo-statefulset.yaml
