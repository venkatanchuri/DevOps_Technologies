#!/bin/bash
ansible-playbook site.yml -i hosts -c paramiko
